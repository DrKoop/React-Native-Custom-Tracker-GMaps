


export interface Location {
    latitude : number;
    longitude : number;
}