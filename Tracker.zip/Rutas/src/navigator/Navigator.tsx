import React, { useContext } from 'react'
import { createStackNavigator } from '@react-navigation/stack';
import { MapScreen } from '../pages/MapScreen'
import { PermissionScreen } from '../pages/PermisionsScreen'; 
import { PermissionsContext } from '../context/PermissionContext';
import LoadingScreen from '../pages/LoadingScreen';

const Stack = createStackNavigator();

export const Navigator = () => {

  const { permissions } = useContext( PermissionsContext );

  if(permissions.locarionStatus === 'unavailable' ){
    return <LoadingScreen/>
  }

  return (
    <Stack.Navigator
      screenOptions={ {
        headerShown : false,
        cardStyle : {
          backgroundColor : 'orange'
        }
       }}
    >
      
      {
        ( permissions.locarionStatus === 'granted' )
        ?  <Stack.Screen name="Home" component={ MapScreen } />
        :   <Stack.Screen name="Notifications" component={PermissionScreen} />
      }
      
      
    </Stack.Navigator>
  );
}