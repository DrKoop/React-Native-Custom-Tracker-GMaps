import { createContext, useEffect, useState } from 'react';
import { PermissionStatus, request, PERMISSIONS, check, openSettings } from 'react-native-permissions';
import { AppState,Platform } from 'react-native';

//Permite saber que informacion fluye
export interface PermissionState {
    locarionStatus : PermissionStatus
}

//Estado inicial 
export const permissionInitState : PermissionState = {
    locarionStatus : 'unavailable',
}

type PermissionsContextProps = {
    permissions : PermissionState;
    askLocationPermission : () => void;
    checkLocationPermission : () => void;
}

export const PermissionsContext = createContext({} as PermissionsContextProps)


//funciones que vamos apermitir que se extiendan a cualquier componente de la App 
export const PermissionsProvider = ( {  children } : any ) => {

    const [ permissions , setPermissions ] = useState(permissionInitState);

    useEffect(() => {
        checkLocationPermission()

        AppState.addEventListener('change', state => {

            if( state !== 'active' ) return;
            checkLocationPermission()
        });

    }, [])


    const askLocationPermission = async () => {
        let permisoStatus : PermissionStatus;

        if ( Platform.OS === 'ios' ){
          //permisoStatus = await check( PERMISSIONS.IOS.LOCATION_WHEN_IN_USE );
          permisoStatus = await request( PERMISSIONS.IOS.LOCATION_WHEN_IN_USE );
        }else{
          //permisoStatus = await check( PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION );
          permisoStatus = await request( PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION );
        }

        
        //*Habilitar permisos a de GPS a la app , y tambien tener habilitado el gps 
        if( permisoStatus === 'blocked'){
            openSettings()
        }

        setPermissions({
            ...permissions,
            locarionStatus : permisoStatus
        })

    }

    const checkLocationPermission = async () => {
        let permisoStatus : PermissionStatus;

        if ( Platform.OS === 'ios' ){
          //permisoStatus = await check( PERMISSIONS.IOS.LOCATION_WHEN_IN_USE );
          permisoStatus = await check( PERMISSIONS.IOS.LOCATION_WHEN_IN_USE );
        }else{
          //permisoStatus = await check( PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION );
          permisoStatus = await check( PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION );
        }
        //*Habilitar permisos a de GPS a la app , y tambien tener habilitado el gps 
        setPermissions({
            ...permissions,
            locarionStatus : permisoStatus
        })
    }

    

    return(
        <PermissionsContext.Provider value={{
            permissions,
            askLocationPermission,
            checkLocationPermission
        }}>
            { children }
        </PermissionsContext.Provider>
    )

}